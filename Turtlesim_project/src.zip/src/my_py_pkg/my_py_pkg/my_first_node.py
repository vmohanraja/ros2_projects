#!/usr/bin/env python3
import rclpy
from rclpy.node import Node

class MyNode(Node):  #modify name
    def __init__(self):
        super().__init__("py_test")  #modify the node name
        self.get_logger().info("Hello Jazzy123")
        self.create_timer(0.5,self.timer_callback)

    def timer_callback(self):
        self.get_logger().info("Hello")


def main(args=None):
    rclpy.init(args=args)
    node = MyNode()   #modify name
    rclpy.spin(node)
    rclpy.shutdown()
if __name__ == "__main__":
    main()